<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/recipe-name" only-nested=true}}
{
	"name": {{html name="name"}}
}
